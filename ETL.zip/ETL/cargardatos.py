import redshift_connector
from ext import nba_data_combined

conn = redshift_connector.connect(
    host="data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com",
    database="data-engineer-database",
    port=5439,
    user="nachomerlogm_coderhouse",
    password="0pT6wSDo43",
)

nba_data_combined.to_sql("nba_top_scorers", conn, if_exists="replace", index=False)
