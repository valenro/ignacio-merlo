import requests
import pandas as pd
import time
from sqlalchemy import create_engine


def get_playoffs(años):
    dfs = []
    try:
        for año in años:
            url = f"https://nba-stats-db.herokuapp.com/api/playerdata/topscorers/playoffs/{año}/"
            payload = {}
            headers = {}
            response = requests.request("GET", url, headers=headers, data=payload)
            data = response.json()
            top_scorer_playoff = data["results"]
            dfs.append(pd.DataFrame(top_scorer_playoff))
    except requests.exceptions.ConnectionError:
        time.sleep(30)

    df_final = pd.concat(dfs, ignore_index=True)
    return df_final


def get_season(años):
    dfs = []
    try:
        for año in años:
            url = f"https://nba-stats-db.herokuapp.com/api/playerdata/topscorers/total/season/{año}/"
            payload = {}
            headers = {}
            response = requests.request("GET", url, headers=headers, data=payload)
            data = response.json()
            top_scorer_playoff = data["results"]
            dfs.append(pd.DataFrame(top_scorer_playoff))
    except requests.exceptions.ConnectionError:
        time.sleep(30)

    df_final = pd.concat(dfs, ignore_index=True)
    return df_final


años = [2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023]
nba_data_playoffs = get_playoffs(años)
nba_data_season = get_season(años)

nba_data_season["instance"] = "Season"
nba_data_playoffs["instance"] = "Playoffs"

try:
    nba_data_combined = pd.concat(
        [nba_data_playoffs, nba_data_season], ignore_index=True
    )
except ValueError:
    print("Sigue tirando el mismo error.")

# Configura la conexión a la base de datos Redshift usando SQLAlchemy
# Reemplaza los valores con la información de tu clúster Redshift
redshift_username = "nachomerlogm_coderhouse"
redshift_password = "0pT6wSDo43"
redshift_host = "data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com"
redshift_port = 5439
redshift_database = "data-engineer-database"

# Crea la cadena de conexión a la base de datos Redshift
connection_string = f"postgresql+psycopg2://{redshift_username}:{redshift_password}@{redshift_host}:{redshift_port}/{redshift_database}?options=-c%20standard_conforming_strings=on"

# Crea una conexión a la base de datos usando la cadena de conexión
engine = create_engine(connection_string)


# Inserta los datos en la tabla nba_top_scorers en Redshift
def cargar():
    try:
        nba_data_combined.to_sql(
            "nba_top_scorers", con=engine, if_exists="replace", index=False
        )
    except Exception as e:
        print("Error al insertar los datos en Redshift:", e)
