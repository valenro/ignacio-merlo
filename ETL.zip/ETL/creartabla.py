import psycopg2
from psycopg2 import OperationalError

try:
    conn = psycopg2.connect(
        host="data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com",
        user="nachomerlogm_coderhouse",
        password="0pT6wSDo43",
        port="5439",
        database="data-engineer-database",
    )
except OperationalError as e:
    print(f"Error connecting to Redshift: {e}")
    exit(1)

cur = conn.cursor()

create_table_query = """
CREATE TABLE nba_top_scorers (
    id integer primary key,
    player_name varchar,
    age integer,
    games integer,
    games_started integer,
    minutes_played integer,
    field_goals integer, 
    field_attemps integer,
    field_percent float,
    three_fg integer,
    three_attemps integer,
    three_percent float,
    two_fg integer,
    two_attemps integer, 
    two_percent float,
    effect_fg_percent float,
    ft integer, 
    fta integer, 
    ft_percent float,
    orb integer,
    drb integer, 
    trb integer, 
    ast integer,
    stl integer,
    blk integer,
    tov integer,
    pf integer,
    pts integer,
    team varchar,
    season integer,
    instance varchar
    );"""


def crear_tabla():
    try:
        cur.execute(create_table_query)
        conn.commit()
        print("Tabla creada exitosamente.")
    except (Exception, psycopg2.DatabaseError) as e:
        print(f"Error al crear la tabla: {e}")
        conn.rollback()

    cur.close()
    conn.close()
