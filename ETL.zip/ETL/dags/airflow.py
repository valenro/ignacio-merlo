import pendulum
from datetime import timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from creartabla import crear_tabla
from ext import (
    cargar,
)  # Aquí deben importar las funciones a ejecutar (las de la entrega 2)

DAG_ID = "My_DAG_name"
DAG_DESCRIPTION = "My_DAG_description"  # Cambia esto a una descripción adecuada
DAG_SCHEDULE = "30 5 */1 * *"
DAG_CATCHUP = False
TAGS = ["Entregable_3"]

ARGS = {
    "owner": "My_name",
    "start_date": pendulum.datetime(2022, 1, 1, tz="America/Mexico_City"),
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id=DAG_ID,
    description=DAG_DESCRIPTION,
    default_args=ARGS,
    schedule_interval=DAG_SCHEDULE,
    catchup=DAG_CATCHUP,
    tags=TAGS,
    max_active_runs=1,
) as dag:
    name_task_1 = PythonOperator(
        task_id="get_playoffs",
        python_callable=cargar.get_playoffs,  # Cambia esto al nombre correcto de la función
        retries=1,
        retry_delay=timedelta(minutes=1),
    )

    name_task_2 = PythonOperator(
        task_id="get_season",
        python_callable=cargar.get_season,  # Cambia esto al nombre correcto de la función
        retries=1,
        retry_delay=timedelta(minutes=1),
    )
    name_task_3 = PythonOperator(
        task_id="crear_tabla",
        python_callable=crear_tabla,  # Cambia esto al nombre correcto de la función
        retries=1,
        retry_delay=timedelta(minutes=1),
    )
    name_task_4 = PythonOperator(
        task_id="cargar",
        python_callable=cargar.cargar,  # Cambia esto al nombre correcto de la función
        retries=1,
        retry_delay=timedelta(minutes=1),
    )

    name_task_1 >> name_task_2 >> name_task_3 >> name_task_4
