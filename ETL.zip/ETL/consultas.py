import psycopg2
from psycopg2 import OperationalError

try:
    conn = psycopg2.connect(
        host='data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com',
        user='nachomerlogm_coderhouse',
        password='0pT6wSDo43',
        port='5439',
        database='data-engineer-database'
    )
except OperationalError as e:
    print(f"Error connecting to Redshift: {e}")
    exit(1)

cur = conn.cursor()

create_table_query = '''
SELECT * FROM nba_top_scorers;
'''

cur.close()
conn.close()
